# VideoForge - AI Video Generator Platform

A comprehensive HeyGen-style SaaS application for creating professional AI videos with realistic talking avatars, 50+ languages, advanced editing, and video translation.

## 🎬 Features

### Core Video Creation
- **Text-to-Video**: Convert scripts into talking-head videos with AI avatars
- **Avatar Library**: 50+ stock avatars with filters (gender, age, style) + custom avatar upload
- **Voice Support**: 50+ languages and accents with speed/tone controls, optional voice cloning
- **Advanced Editor**: Timeline-based interface with scenes, backgrounds, music, text overlays, subtitles
- **Video Translation**: Upload videos and get dubbed versions with lip-sync
- **Templates**: Pre-made layouts for ads, training, social media, and product demos
- **Aspect Ratios**: Support for 16:9, 9:16, and 1:1 formats

### Project Management
- **Dashboard**: View all projects with status tracking
- **Draft Management**: Save and organize projects
- **Rendering Queue**: Real-time progress tracking
- **Download & Export**: MP4 format with quality options
- **Share Links**: Generate shareable links with optional download permissions

### Business Features
- **Credit-Based Pricing**: Free (watermark, short videos), Creator, Business tiers
- **Stripe Integration**: Subscription management and billing
- **Usage Tracking**: Monitor credits consumed and remaining
- **API Access**: Developer-friendly REST API with webhooks
- **Analytics**: Track video views and engagement

### Developer Tools
- **REST API**: Full programmatic access to all features
- **API Keys**: Generate and manage access credentials
- **Webhooks**: Real-time notifications for video completion
- **Documentation**: Complete API reference with code examples

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 16 (App Router) with React 19
- **Styling**: Tailwind CSS 4
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Custom session-based auth with bcrypt
- **Payments**: Stripe integration
- **AI Video APIs**: Prepared for HeyGen, D-ID, Synthesia integration

### Database Schema
- **users**: User accounts with subscription and credit tracking
- **projects**: Video projects with metadata and status
- **scenes**: Individual scenes within projects
- **video_renders**: Rendering history and status
- **avatars**: Stock and custom avatar library
- **voices**: Voice options with language support
- **share_links**: Shareable links for video distribution
- **billing_history**: Transaction history
- **api_keys**: Developer API access keys
- **translation_jobs**: Video translation tracking

## 🚀 Getting Started

### Installation

```bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Initialize database
npx drizzle-kit push

# Run development server
npm run dev
```

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/videoforge

# Stripe (Optional)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000

# AI Video APIs (Optional - Add when ready)
HEYGEN_API_KEY=...
DID_API_KEY=...
SYNTHESIA_API_KEY=...
ELEVENLABS_API_KEY=...
```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login

### Projects
- `GET /api/projects` - List user's projects
- `POST /api/projects` - Create new project
- `GET /api/projects/:projectId` - Get project details
- `PATCH /api/projects/:projectId` - Update project
- `DELETE /api/projects/:projectId` - Delete project

### Scenes
- `GET /api/projects/:projectId/scenes` - List scenes
- `POST /api/projects/:projectId/scenes` - Create scene

### Video Rendering
- `POST /api/projects/:projectId/render` - Start rendering
- `GET /api/projects/:projectId/render` - Get render status

### Library
- `GET /api/avatars` - List available avatars
- `GET /api/voices` - List available voices

### Sharing
- `POST /api/projects/:projectId/share` - Create share link
- `GET /api/projects/:projectId/share` - List share links

### Billing
- `POST /api/billing/create-checkout` - Start subscription

### Developer
- `GET /api/api-keys` - List API keys
- `POST /api/api-keys` - Create API key

## 🎨 UI Pages

- **Landing** (`/`): Marketing homepage with features and pricing
- **Authentication** (`/login`, `/register`): User signup/signin
- **Dashboard** (`/dashboard`): Main project hub
- **Editor** (`/editor/[projectId]`): Video creation interface
- **Settings** (`/settings`): Profile, billing, API keys
- **API Docs** (`/docs`): API reference documentation
- **Watch** (`/watch/[token]`): Public video viewing

## 🔌 Third-Party Integrations

### AI Video Generation (Ready to Integrate)

#### HeyGen
- Documentation: https://docs.heygen.com/
- Avatar support, voice synthesis, video generation
- Integration point: `/api/projects/[projectId]/render`

#### D-ID
- Documentation: https://docs.d-id.com/
- Realistic avatar animations
- Real-time video generation

#### Synthesia
- Documentation: https://synthesia.readme.io/
- AI presenters and avatars
- Video templates

#### Voice Synthesis
- ElevenLabs: https://elevenlabs.io/docs
- Google Cloud TTS
- Azure Speech Services

### Implementation Guide

1. Sign up for API key on chosen platform
2. Add credentials to `.env`
3. Implement API calls in `/api/projects/[projectId]/render/route.ts`
4. Store `externalJobId` and `externalProvider` for tracking
5. Set up webhook or polling for status updates
6. Return video URL when complete

## 💳 Credit System

### Free Plan
- 100 credits/month
- Watermarked videos
- Max 2 minutes
- 5 avatars

### Creator Plan ($29/month)
- 1,000 credits/month
- No watermark
- Unlimited length
- 50+ avatars
- 1 custom avatar

### Business Plan ($99/month)
- 5,000 credits/month
- Everything in Creator
- 3 custom avatars
- Voice cloning
- API access
- Analytics

## 🔐 Security

- Passwords hashed with bcrypt
- Session-based authentication
- User-scoped API access
- Stripe PCI compliance
- CORS protection
- Rate limiting ready

## 📊 Database Schema Overview

```
Users
├─ Subscriptions (Stripe)
├─ Credits & Usage
├─ Projects
│  ├─ Scenes
│  │  ├─ Avatar Selection
│  │  └─ Voice Configuration
│  ├─ Video Renders
│  └─ Share Links
├─ API Keys
└─ Billing History
```

## 🚢 Deployment

### Production Build
```bash
npm run build
npm run start
```

### Database Migrations
```bash
npx drizzle-kit push
```

### Stripe Webhooks
Configure in Stripe Dashboard:
- Endpoint: `https://yourdomain.com/api/webhooks/stripe`
- Events: `checkout.session.completed`, `customer.subscription.deleted`, `invoice.payment_succeeded`

## 📝 Development Roadmap

- [ ] HeyGen API integration
- [ ] D-ID API integration
- [ ] Video translation feature
- [ ] Custom avatar upload processing
- [ ] Voice cloning workflow
- [ ] Analytics dashboard
- [ ] Batch video rendering
- [ ] Team collaboration features
- [ ] Mobile app

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

## 📄 License

MIT License - See LICENSE file for details

## 🆘 Support

- Documentation: `/docs` page
- API Reference: Full endpoint documentation included
- Issues: GitHub issues tracker
- Email: support@videoforge.io

## 🙏 Acknowledgments

- Next.js community
- Tailwind CSS
- Drizzle ORM
- Stripe
- HeyGen, D-ID, Synthesia for AI video technology

---

Built with ❤️ by the VideoForge team
