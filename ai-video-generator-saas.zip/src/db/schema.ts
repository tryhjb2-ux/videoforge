import {
  pgTable,
  pgEnum,
  text,
  varchar,
  boolean,
  integer,
  timestamp,
  uuid,
  decimal,
  json,
  jsonb,
} from "drizzle-orm/pg-core";

// Enums
export const userRoleEnum = pgEnum("user_role", ["admin", "user"]);
export const planEnum = pgEnum("plan_type", ["free", "creator", "business"]);
export const projectStatusEnum = pgEnum("project_status", [
  "draft",
  "processing",
  "completed",
  "failed",
]);
export const videoStatusEnum = pgEnum("video_status", [
  "pending",
  "queued",
  "generating",
  "processing",
  "completed",
  "failed",
]);
export const avatarGenderEnum = pgEnum("avatar_gender", [
  "male",
  "female",
  "neutral",
]);
export const avatarStyleEnum = pgEnum("avatar_style", [
  "professional",
  "casual",
  "formal",
  "creative",
  "animated",
]);

// Users table
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  password: text("password"),
  avatar: varchar("avatar", { length: 500 }),
  plan: planEnum("plan").notNull().default("free"),
  credits: integer("credits").notNull().default(100), // Free tier gets 100 credits
  creditsUsed: integer("credits_used").notNull().default(0),
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  subscriptionStatus: varchar("subscription_status", { length: 50 }),
  subscriptionEndDate: timestamp("subscription_end_date"),
  emailVerified: boolean("email_verified").default(false),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Projects table
export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: projectStatusEnum("status").notNull().default("draft"),
  thumbnail: varchar("thumbnail", { length: 500 }),
  script: text("script"),
  aspectRatio: varchar("aspect_ratio", { length: 10 }).default("16:9"), // 16:9, 9:16, 1:1
  backgroundColor: varchar("background_color", { length: 20 }).default("#000000"),
  template: varchar("template", { length: 50 }), // ads, training, social, product_demo
  metadata: jsonb("metadata"), // Stores additional data
  renderProgress: integer("render_progress").default(0), // 0-100
  renderStartedAt: timestamp("render_started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Video renders table
export const videoRenders = pgTable("video_renders", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  status: videoStatusEnum("status").notNull().default("pending"),
  videoUrl: varchar("video_url", { length: 500 }),
  duration: integer("duration"), // in seconds
  fileSize: integer("file_size"), // in bytes
  errorMessage: text("error_message"),
  creditsCost: integer("credits_cost").notNull().default(50),
  externalJobId: varchar("external_job_id", { length: 255 }), // For tracking with third-party APIs
  externalProvider: varchar("external_provider", { length: 50 }), // heygen, d-id, synthesia
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  expiresAt: timestamp("expires_at"), // Video links may expire
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Scenes table (for timeline-based editing)
export const scenes = pgTable("scenes", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  orderIndex: integer("order_index").notNull(),
  duration: decimal("duration", { precision: 10, scale: 2 }).notNull(), // in seconds
  text: text("text"),
  avatarId: uuid("avatar_id").references(() => avatars.id, { onDelete: "set null" }),
  voiceId: uuid("voice_id").references(() => voices.id, { onDelete: "set null" }),
  backgroundImage: varchar("background_image", { length: 500 }),
  textOverlays: jsonb("text_overlays"), // Array of {text, position, style}
  music: varchar("music", { length: 500 }), // URL to music file
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Avatars library table
export const avatars = pgTable("avatars", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }), // NULL for stock avatars
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  videoPreviewUrl: varchar("video_preview_url", { length: 500 }),
  gender: avatarGenderEnum("gender"),
  ageRange: varchar("age_range", { length: 20 }), // e.g., "25-35"
  style: avatarStyleEnum("style"),
  skinTone: varchar("skin_tone", { length: 50 }),
  isCustom: boolean("is_custom").default(false),
  isPublic: boolean("is_public").default(true), // Only applies to custom avatars
  externalId: varchar("external_id", { length: 255 }), // ID from HeyGen, D-ID, etc.
  externalProvider: varchar("external_provider", { length: 50 }), // Which API provides this
  metadata: jsonb("metadata"), // Extra avatar data
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Voices library table
export const voices = pgTable("voices", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }), // NULL for stock voices
  name: varchar("name", { length: 255 }).notNull(),
  language: varchar("language", { length: 50 }).notNull(), // e.g., "en-US"
  accent: varchar("accent", { length: 50 }),
  gender: avatarGenderEnum("gender"),
  speed: decimal("speed", { precision: 3, scale: 1 }).default("1.0"), // 0.5 to 2.0
  tone: varchar("tone", { length: 50 }), // professional, casual, friendly, etc.
  isClone: boolean("is_clone").default(false),
  isPublic: boolean("is_public").default(true),
  externalId: varchar("external_id", { length: 255 }), // ID from ElevenLabs, Google Cloud TTS, etc.
  externalProvider: varchar("external_provider", { length: 50 }), // elevenlabs, google, azure, etc.
  metadata: jsonb("metadata"), // Extra voice data
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Share links table
export const shareLinks = pgTable("share_links", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at"),
  viewCount: integer("view_count").default(0),
  allowDownload: boolean("allow_download").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Billing/Usage tracking table
export const billingHistory = pgTable("billing_history", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(), // "render", "subscription", "purchase"
  amount: decimal("amount", { precision: 10, scale: 2 }),
  credits: integer("credits"),
  stripeTransactionId: varchar("stripe_transaction_id", { length: 255 }),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// API Keys for developers
export const apiKeys = pgTable("api_keys", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  key: varchar("key", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  lastUsedAt: timestamp("last_used_at"),
  rateLimit: integer("rate_limit").default(100), // requests per minute
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Translation jobs table (for video translation feature)
export const translationJobs = pgTable("translation_jobs", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  sourceProjectId: uuid("source_project_id").references(
    () => projects.id,
    { onDelete: "cascade" }
  ),
  targetProjectId: uuid("target_project_id").references(
    () => projects.id,
    { onDelete: "cascade" }
  ),
  sourceLanguage: varchar("source_language", { length: 50 }).notNull(),
  targetLanguage: varchar("target_language", { length: 50 }).notNull(),
  status: videoStatusEnum("status").notNull().default("pending"),
  externalJobId: varchar("external_job_id", { length: 255 }),
  errorMessage: text("error_message"),
  creditsCost: integer("credits_cost").notNull().default(100),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});
