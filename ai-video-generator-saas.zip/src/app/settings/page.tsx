"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Copy, Plus, Trash2 } from "lucide-react";

interface User {
  id: string;
  name: string;
  email: string;
  plan: string;
  credits: number;
}

export default function SettingsPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [apiKeys, setApiKeys] = useState<any[]>([]);
  const [showNewKeyForm, setShowNewKeyForm] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      router.push("/login");
      return;
    }

    const userData = JSON.parse(userStr);
    setUser(userData);
  }, [router]);

  const handleCreateApiKey = async () => {
    if (!newKeyName || !user) return;

    try {
      const response = await fetch("/api/api-keys", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": user.id,
        },
        body: JSON.stringify({
          name: newKeyName,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create API key");
      }

      const newKey = await response.json();
      setApiKeys([...apiKeys, newKey]);
      setNewKeyName("");
      setShowNewKeyForm(false);
    } catch (error) {
      console.error("Error creating API key:", error);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-gray-800 bg-gray-950/80 backdrop-blur-md">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link href="/dashboard" className="text-gray-400 hover:text-white transition">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">Settings</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Section */}
        <section className="bg-gray-900/50 border border-gray-800 rounded-xl p-8 mb-8">
          <h2 className="text-xl font-bold mb-6">Profile</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Name</label>
              <input
                type="text"
                value={user.name}
                disabled
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Email</label>
              <input
                type="email"
                value={user.email}
                disabled
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Plan</label>
                <div className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg capitalize">
                  {user.plan}
                </div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Credits Available</label>
                <div className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg">
                  {user.credits}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Billing Section */}
        <section className="bg-gray-900/50 border border-gray-800 rounded-xl p-8 mb-8">
          <h2 className="text-xl font-bold mb-6">Billing</h2>
          <div className="space-y-4">
            <button className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition">
              Upgrade Plan
            </button>
            <button className="w-full px-6 py-3 border border-gray-700 hover:border-gray-600 rounded-lg font-medium transition">
              View Billing History
            </button>
          </div>
        </section>

        {/* API Keys Section */}
        <section className="bg-gray-900/50 border border-gray-800 rounded-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">API Keys</h2>
            <button
              onClick={() => setShowNewKeyForm(!showNewKeyForm)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              New Key
            </button>
          </div>

          {showNewKeyForm && (
            <div className="mb-6 p-4 bg-gray-800 border border-gray-700 rounded-lg space-y-3">
              <input
                type="text"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder="API Key Name (e.g., 'Production')"
                className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none"
              />
              <div className="flex gap-2">
                <button
                  onClick={handleCreateApiKey}
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition"
                >
                  Create Key
                </button>
                <button
                  onClick={() => setShowNewKeyForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-700 hover:border-gray-600 rounded-lg font-medium transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {apiKeys.length === 0 ? (
            <p className="text-gray-400">No API keys yet. Create one to start using the API.</p>
          ) : (
            <div className="space-y-3">
              {apiKeys.map((key) => (
                <div
                  key={key.id}
                  className="p-4 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-between"
                >
                  <div>
                    <p className="font-medium">{key.name}</p>
                    <p className="text-sm text-gray-500 font-mono">
                      {key.key.substring(0, 10)}...
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 hover:bg-gray-700 rounded transition">
                      <Copy className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-700 rounded transition">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
