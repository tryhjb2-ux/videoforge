"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";
import {
  Download,
  Share2,
  Settings,
  Play,
  Upload,
  Trash2,
  Plus,
  ChevronDown,
} from "lucide-react";

interface Project {
  id: string;
  userId: string;
  title: string;
  description: string;
  script: string;
  status: string;
  aspectRatio: string;
}

interface Scene {
  id: string;
  projectId: string;
  orderIndex: number;
  duration: number;
  text: string;
  avatarId: string | null;
  voiceId: string | null;
}

export default function EditorPage() {
  const router = useRouter();
  const params = useParams();
  const projectId = Array.isArray(params.projectId) ? params.projectId[0] : (params.projectId as string);

  const [user, setUser] = useState<any>(null);
  const [project, setProject] = useState<Project | null>(null);
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [selectedScene, setSelectedScene] = useState<string | null>(null);
  const [showAvatarMenu, setShowAvatarMenu] = useState(false);
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      router.push("/login");
      return;
    }

    const userData = JSON.parse(userStr);
    setUser(userData);

    fetchProject(userData.id);
  }, [projectId, router]);

  const fetchProject = async (userId: string) => {
    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        headers: {
          "x-user-id": userId,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch project");
      }

      const data = await response.json();
      setProject(data);
    } catch (error) {
      console.error("Error fetching project:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleScriptChange = async (newScript: string) => {
    if (!project) return;

    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": user.id,
        },
        body: JSON.stringify({
          script: newScript,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to update project");
      }

      setProject({ ...project, script: newScript });
    } catch (error) {
      console.error("Error updating project:", error);
    }
  };

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white flex items-center justify-center">
        <p className="text-gray-400">Loading editor...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-gray-800 bg-gray-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link
              href="/dashboard"
              className="text-gray-400 hover:text-white transition"
            >
              ← Back
            </Link>
            <h1 className="text-xl font-bold">{project?.title || "Untitled"}</h1>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 border border-gray-700 hover:border-gray-600 rounded-lg font-medium transition flex items-center gap-2">
              <Play className="w-4 h-4" />
              Preview
            </button>
            <button className="px-4 py-2 border border-gray-700 hover:border-gray-600 rounded-lg font-medium transition flex items-center gap-2">
              <Download className="w-4 h-4" />
              Render
            </button>
            <button className="px-4 py-2 border border-gray-700 hover:border-gray-600 rounded-lg font-medium transition flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </button>
          </div>
        </div>
      </header>

      {/* Main Editor */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-3 gap-8">
          {/* Script Panel */}
          <div className="col-span-1">
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h2 className="text-lg font-semibold mb-4">Script</h2>
              <textarea
                value={project?.script || ""}
                onChange={(e) => handleScriptChange(e.target.value)}
                placeholder="Paste your script here..."
                className="w-full h-96 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none resize-none text-sm"
              />
              <div className="mt-4 text-xs text-gray-500">
                <p>Tips:</p>
                <ul className="list-disc list-inside space-y-1 mt-2">
                  <li>Keep it under 2 minutes for free plan</li>
                  <li>Use natural pauses with commas</li>
                  <li>Add [pause] for longer breaks</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Preview & Controls */}
          <div className="col-span-2 space-y-6">
            {/* Video Preview */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mx-auto mb-4 opacity-50"></div>
                  <p className="text-gray-400">Video Preview</p>
                  <p className="text-xs text-gray-500 mt-2">
                    Generated videos appear here
                  </p>
                </div>
              </div>
            </div>

            {/* Avatar Selection */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center justify-between">
                Avatar
                <button
                  onClick={() => setShowAvatarMenu(!showAvatarMenu)}
                  className="text-xs px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded transition"
                >
                  Browse
                </button>
              </h3>
              <div className="grid grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <button
                    key={i}
                    className="aspect-square bg-gray-800 border-2 border-gray-700 hover:border-blue-500 rounded-lg flex items-center justify-center transition"
                  >
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full opacity-50"></div>
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Selection */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center justify-between">
                Voice
                <button
                  onClick={() => setShowVoiceMenu(!showVoiceMenu)}
                  className="text-xs px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded transition"
                >
                  Browse
                </button>
              </h3>
              <div className="space-y-2">
                <div>
                  <label className="text-sm text-gray-400">Language</label>
                  <select className="w-full mt-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none">
                    <option>English (US)</option>
                    <option>Spanish (Spain)</option>
                    <option>French (France)</option>
                    <option>German (Germany)</option>
                    <option>Chinese (Mandarin)</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Accent</label>
                  <select className="w-full mt-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:border-blue-500 focus:outline-none">
                    <option>Standard</option>
                    <option>British</option>
                    <option>Australian</option>
                    <option>Indian</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Speed</label>
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    defaultValue="1"
                    className="w-full mt-1"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="mt-8 bg-gray-900/50 border border-gray-800 rounded-xl p-6">
          <h3 className="font-semibold mb-4">Timeline</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-4 p-3 bg-gray-800 rounded-lg border border-gray-700">
              <span className="text-sm font-medium w-20">Scene 1</span>
              <input
                type="range"
                min="0"
                max="100"
                defaultValue="50"
                className="flex-1"
              />
              <span className="text-sm text-gray-400 w-12">30s</span>
            </div>
            <button className="w-full py-2 border-2 border-dashed border-gray-700 hover:border-gray-600 rounded-lg text-gray-400 transition flex items-center justify-center gap-2">
              <Plus className="w-4 h-4" />
              Add Scene
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
