"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Download } from "lucide-react";

interface ShareLink {
  id: string;
  projectId: string;
  token: string;
  allowDownload: boolean;
  viewCount: number;
  expiresAt: string;
}

interface Project {
  id: string;
  title: string;
  description: string;
}

export default function WatchPage() {
  const params = useParams();
  const token = params.token as string;

  const [shareLink, setShareLink] = useState<ShareLink | null>(null);
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchShareLink();
  }, [token]);

  const fetchShareLink = async () => {
    try {
      // This endpoint would be: GET /api/share/[token]
      // For demo purposes, showing the structure
      console.log("Fetching share link:", token);
      setLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load video");
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white flex items-center justify-center">
        <p className="text-gray-400">Loading video...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400 mb-4">{error}</p>
          <p className="text-gray-400">This link may have expired or been removed.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-md py-4">
        <div className="max-w-5xl mx-auto px-4">
          <a href="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            VideoForge
          </a>
        </div>
      </header>

      {/* Video Container */}
      <main className="max-w-5xl mx-auto px-4 py-12">
        <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden">
          {/* Video Player */}
          <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mx-auto mb-4 opacity-50"></div>
              <p className="text-gray-400">Video Player</p>
              <p className="text-xs text-gray-500 mt-2">
                In production, this would embed the actual video from HeyGen/D-ID
              </p>
            </div>
          </div>

          {/* Video Info */}
          <div className="p-6">
            <h1 className="text-3xl font-bold mb-2">{project?.title || "Untitled Video"}</h1>
            <p className="text-gray-400 mb-6">
              {project?.description || "No description"}
            </p>

            {shareLink?.allowDownload && (
              <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold flex items-center gap-2 transition">
                <Download className="w-4 h-4" />
                Download Video
              </button>
            )}
          </div>
        </div>

        {/* Powered by */}
        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>Created with <span className="text-blue-400">VideoForge</span></p>
        </div>
      </main>
    </div>
  );
}
