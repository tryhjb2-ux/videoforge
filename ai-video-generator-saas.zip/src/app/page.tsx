import Link from "next/link";
import { ArrowRight, Zap, Users, BarChart3, Globe, Layers, Code } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-black text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-gray-800 bg-gray-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            VideoForge
          </div>
          <div className="flex gap-4 items-center">
            <Link
              href="/login"
              className="px-6 py-2 text-sm font-medium text-gray-300 hover:text-white transition"
            >
              Sign In
            </Link>
            <Link
              href="/register"
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Create AI Videos in <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Minutes</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Turn scripts into professional talking-head videos with realistic AI avatars, multiple languages, and lifelike voices.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Link
                href="/register"
                className="px-8 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold flex items-center gap-2 transition"
              >
                Start Free Trial <ArrowRight className="w-4 h-4" />
              </Link>
              <button className="px-8 py-3 border border-gray-700 hover:border-gray-500 rounded-lg font-semibold transition">
                Watch Demo
              </button>
            </div>
            <p className="text-sm text-gray-500 mt-6">
              No credit card required • 100 free credits • Cancel anytime
            </p>
          </div>
          <div className="relative h-96 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl border border-gray-800 flex items-center justify-center">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mx-auto mb-4 opacity-50"></div>
              <p className="text-gray-400">Video Preview</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold mb-16 text-center">Powerful Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Zap,
              title: "Text-to-Video",
              description: "Paste your script and watch it transform into a professional video with realistic avatars",
            },
            {
              icon: Users,
              title: "Avatar Library",
              description: "Choose from 50+ stock avatars or upload your own custom avatar for personalized videos",
            },
            {
              icon: Globe,
              title: "50+ Languages",
              description: "Create videos in any language with natural-sounding voices and perfect lip-sync",
            },
            {
              icon: Layers,
              title: "Advanced Editor",
              description: "Timeline-based editor with scenes, backgrounds, music, text overlays, and subtitles",
            },
            {
              icon: BarChart3,
              title: "Analytics",
              description: "Track video performance and engagement with built-in analytics dashboard",
            },
            {
              icon: Code,
              title: "API Access",
              description: "Integrate VideoForge into your app with our comprehensive API and webhooks",
            },
          ].map((feature, i) => (
            <div
              key={i}
              className="p-6 bg-gray-900/50 border border-gray-800 rounded-xl hover:border-gray-700 transition"
            >
              <feature.icon className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold mb-16 text-center">Simple Pricing</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              name: "Free",
              price: "$0",
              credits: "100 credits/month",
              features: [
                "Watermarked videos",
                "Up to 2 min videos",
                "5 avatars",
                "Basic editor",
              ],
            },
            {
              name: "Creator",
              price: "$29",
              credits: "1,000 credits/month",
              features: [
                "No watermark",
                "Unlimited length",
                "50+ avatars",
                "Advanced editor",
                "1 custom avatar",
                "Email support",
              ],
              highlighted: true,
            },
            {
              name: "Business",
              price: "$99",
              credits: "5,000 credits/month",
              features: [
                "Everything in Creator",
                "3 custom avatars",
                "Voice cloning",
                "API access",
                "Priority support",
                "Analytics",
              ],
            },
          ].map((plan, i) => (
            <div
              key={i}
              className={`p-8 rounded-xl border transition ${
                plan.highlighted
                  ? "bg-blue-600/10 border-blue-500/50 ring-2 ring-blue-500/20"
                  : "bg-gray-900/50 border-gray-800 hover:border-gray-700"
              }`}
            >
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-3xl font-bold mb-1">{plan.price}</p>
              <p className="text-sm text-gray-400 mb-6">{plan.credits}</p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-2 text-gray-300">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              <button
                className={`w-full py-2 rounded-lg font-semibold transition ${
                  plan.highlighted
                    ? "bg-blue-600 hover:bg-blue-700 text-white"
                    : "bg-gray-800 hover:bg-gray-700 text-white"
                }`}
              >
                Get Started
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Ready to Create Amazing Videos?</h2>
        <p className="text-xl text-gray-400 mb-8">
          Join thousands of creators and businesses using VideoForge to create engaging AI videos.
        </p>
        <Link
          href="/register"
          className="inline-block px-8 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition"
        >
          Start Free Today
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>&copy; 2024 VideoForge. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
