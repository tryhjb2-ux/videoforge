import Link from "next/link";
import { ArrowLeft, Code2 } from "lucide-react";

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-gray-800 bg-gray-950/80 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link href="/" className="text-gray-400 hover:text-white transition">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">API Documentation</h1>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Introduction */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-4">Getting Started</h2>
          <p className="text-gray-400 mb-4">
            The VideoForge API allows you to programmatically create, manage, and render AI videos from your own applications.
          </p>
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <p className="text-sm text-gray-300">
              <strong>Base URL:</strong> <code className="bg-gray-800 px-2 py-1 rounded">https://api.videoforge.io/v1</code>
            </p>
          </div>
        </section>

        {/* Authentication */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-4">Authentication</h2>
          <p className="text-gray-400 mb-4">
            All API requests require an API key in the Authorization header:
          </p>
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 font-mono text-sm overflow-x-auto">
            <pre className="text-gray-300">{`Authorization: Bearer vf_your_api_key_here

curl https://api.videoforge.io/v1/projects \\
  -H "Authorization: Bearer vf_your_api_key_here"`}</pre>
          </div>
          <p className="text-gray-400 mt-4">
            Get your API key from your <Link href="/settings" className="text-blue-400 hover:text-blue-300">settings page</Link>.
          </p>
        </section>

        {/* Endpoints */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Endpoints</h2>

          <div className="space-y-8">
            {/* Projects */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-blue-400" />
                Projects
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-mono text-blue-400 mb-2">GET /projects</p>
                  <p className="text-gray-400">List all projects for the authenticated user.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-blue-400 mb-2">POST /projects</p>
                  <p className="text-gray-400">Create a new project.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-blue-400 mb-2">GET /projects/:projectId</p>
                  <p className="text-gray-400">Get a specific project.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-blue-400 mb-2">PATCH /projects/:projectId</p>
                  <p className="text-gray-400">Update a project.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-blue-400 mb-2">DELETE /projects/:projectId</p>
                  <p className="text-gray-400">Delete a project.</p>
                </div>
              </div>
            </div>

            {/* Scenes */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-purple-400" />
                Scenes
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-mono text-purple-400 mb-2">
                    GET /projects/:projectId/scenes
                  </p>
                  <p className="text-gray-400">List all scenes in a project.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-purple-400 mb-2">
                    POST /projects/:projectId/scenes
                  </p>
                  <p className="text-gray-400">Create a new scene.</p>
                </div>
              </div>
            </div>

            {/* Video Rendering */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-green-400" />
                Video Rendering
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-mono text-green-400 mb-2">
                    POST /projects/:projectId/render
                  </p>
                  <p className="text-gray-400">Start rendering a video.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-green-400 mb-2">
                    GET /projects/:projectId/render
                  </p>
                  <p className="text-gray-400">Get render status and history.</p>
                </div>
              </div>
            </div>

            {/* Avatars & Voices */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-pink-400" />
                Avatars & Voices
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-mono text-pink-400 mb-2">GET /avatars</p>
                  <p className="text-gray-400">List available avatars.</p>
                </div>
                <div>
                  <p className="text-sm font-mono text-pink-400 mb-2">GET /voices</p>
                  <p className="text-gray-400">List available voices with language support.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Code Examples */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Code Examples</h2>

          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <h3 className="text-lg font-bold mb-4">Create a Video (JavaScript)</h3>
            <pre className="bg-gray-800 p-4 rounded text-sm text-gray-300 overflow-x-auto">
{`const apiKey = 'vf_your_key';

// 1. Create project
const project = await fetch('https://api.videoforge.io/v1/projects', {
  method: 'POST',
  headers: {
    'Authorization': \`Bearer \${apiKey}\`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    title: 'My First Video',
    description: 'A test video'
  })
}).then(r => r.json());

// 2. Create scene with script
const scene = await fetch(
  \`https://api.videoforge.io/v1/projects/\${project.id}/scenes\`,
  {
    method: 'POST',
    headers: {
      'Authorization': \`Bearer \${apiKey}\`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      text: 'Hello, this is my AI video!',
      avatarId: 'avatar_sarah',
      voiceId: 'voice_emma_us',
      duration: 10
    })
  }
).then(r => r.json());

// 3. Render video
const render = await fetch(
  \`https://api.videoforge.io/v1/projects/\${project.id}/render\`,
  {
    method: 'POST',
    headers: {
      'Authorization': \`Bearer \${apiKey}\`,
      'Content-Type': 'application/json'
    }
  }
).then(r => r.json());

console.log('Video rendering:', render);`}
            </pre>
          </div>
        </section>

        {/* Rate Limiting */}
        <section>
          <h2 className="text-3xl font-bold mb-4">Rate Limiting</h2>
          <p className="text-gray-400">
            Free tier: 100 requests per minute | Creator: 500 requests per minute | Business: 2,000 requests per minute
          </p>
        </section>
      </main>
    </div>
  );
}
