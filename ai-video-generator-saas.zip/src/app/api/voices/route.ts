import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { voices, users } from "@/db/schema";
import { eq } from "drizzle-orm";

// Middleware to verify user from header
async function getUserFromRequest(request: NextRequest) {
  const userId = request.headers.get("x-user-id");
  if (!userId) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId));

  return user[0] || null;
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get public voices
    const publicVoices = await db
      .select()
      .from(voices)
      .where(eq(voices.isPublic, true));

    return NextResponse.json(publicVoices);
  } catch (error) {
    console.error("Get voices error:", error);
    return NextResponse.json(
      { error: "Failed to fetch voices" },
      { status: 500 }
    );
  }
}
