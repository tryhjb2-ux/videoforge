import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { avatars, voices } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    // Check if avatars already exist
    const existingAvatars = await db.select().from(avatars);

    if (existingAvatars.length > 0) {
      return NextResponse.json({ message: "Database already initialized" });
    }

    // Seed stock avatars
    const stockAvatars = [
      {
        name: "Sarah Professional",
        description: "Professional woman avatar",
        imageUrl: "https://via.placeholder.com/300x400?text=Sarah",
        videoPreviewUrl: "https://via.placeholder.com/300x400?text=Preview",
        gender: "female" as const,
        ageRange: "30-40",
        style: "professional" as const,
        skinTone: "Light",
        isCustom: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "James Executive",
        description: "Executive man avatar",
        imageUrl: "https://via.placeholder.com/300x400?text=James",
        videoPreviewUrl: "https://via.placeholder.com/300x400?text=Preview",
        gender: "male" as const,
        ageRange: "35-50",
        style: "formal" as const,
        skinTone: "Medium",
        isCustom: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Maya Creative",
        description: "Creative woman avatar",
        imageUrl: "https://via.placeholder.com/300x400?text=Maya",
        videoPreviewUrl: "https://via.placeholder.com/300x400?text=Preview",
        gender: "female" as const,
        ageRange: "25-35",
        style: "creative" as const,
        skinTone: "Dark",
        isCustom: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Alex Casual",
        description: "Casual person avatar",
        imageUrl: "https://via.placeholder.com/300x400?text=Alex",
        videoPreviewUrl: "https://via.placeholder.com/300x400?text=Preview",
        gender: "neutral" as const,
        ageRange: "20-30",
        style: "casual" as const,
        skinTone: "Light",
        isCustom: false,
        isPublic: true,
        externalProvider: "stock",
      },
    ];

    await db.insert(avatars).values(stockAvatars);

    // Seed stock voices
    const stockVoices = [
      {
        name: "Emma (US English)",
        language: "en-US",
        accent: "American",
        gender: "female" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "James (US English)",
        language: "en-US",
        accent: "American",
        gender: "male" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Sophie (UK English)",
        language: "en-GB",
        accent: "British",
        gender: "female" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Marcus (UK English)",
        language: "en-GB",
        accent: "British",
        gender: "male" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Maria (Spanish)",
        language: "es-ES",
        accent: "Spain",
        gender: "female" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
      {
        name: "Carlos (Spanish)",
        language: "es-ES",
        accent: "Spain",
        gender: "male" as const,
        speed: "1.0",
        tone: "professional",
        isClone: false,
        isPublic: true,
        externalProvider: "stock",
      },
    ];

    for (const voice of stockVoices) {
      await db.insert(voices).values(voice);
    }

    return NextResponse.json({ message: "Database initialized successfully" });
  } catch (error) {
    console.error("Initialization error:", error);
    return NextResponse.json(
      { error: "Failed to initialize database" },
      { status: 500 }
    );
  }
}
