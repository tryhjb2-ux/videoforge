import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { avatars, users } from "@/db/schema";
import { eq } from "drizzle-orm";

// Middleware to verify user from header
async function getUserFromRequest(request: NextRequest) {
  const userId = request.headers.get("x-user-id");
  if (!userId) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId));

  return user[0] || null;
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get public avatars
    const publicAvatars = await db
      .select()
      .from(avatars)
      .where(eq(avatars.isPublic, true));

    return NextResponse.json(publicAvatars);
  } catch (error) {
    console.error("Get avatars error:", error);
    return NextResponse.json(
      { error: "Failed to fetch avatars" },
      { status: 500 }
    );
  }
}
