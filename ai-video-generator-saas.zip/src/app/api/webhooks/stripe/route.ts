import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, billingHistory } from "@/db/schema";
import { eq } from "drizzle-orm";
import Stripe from "stripe";

function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not configured");
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const sig = request.headers.get("stripe-signature") || "";
    const stripe = getStripe();

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(
        body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET || ""
      );
    } catch (err) {
      console.error("Webhook signature verification failed:", err);
      return NextResponse.json(
        { error: "Invalid signature" },
        { status: 400 }
      );
    }

    // Handle different event types
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const metadata = session.metadata as any;
        const userId = metadata?.userId;
        const plan = metadata?.plan;

        if (userId && plan) {
          // Update user subscription
          await db
            .update(users)
            .set({
              plan: plan as any,
              stripeSubscriptionId: session.subscription as string,
              subscriptionStatus: "active",
              credits: plan === "creator" ? 1000 : plan === "business" ? 5000 : 100,
            })
            .where(eq(users.id, userId));

          // Log billing event
          await db.insert(billingHistory).values({
            userId,
            type: "subscription",
            description: `Upgraded to ${plan} plan`,
            stripeTransactionId: session.id,
          });
        }
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;

        // Find user by Stripe customer ID and downgrade to free
        const userList = await db
          .select()
          .from(users);

        const user = userList.find(u => u.stripeCustomerId === customerId);

        if (user) {
          await db
            .update(users)
            .set({
              plan: "free",
              stripeSubscriptionId: null,
              subscriptionStatus: "cancelled",
              credits: 100,
            })
            .where(eq(users.id, user.id));

          await db.insert(billingHistory).values({
            userId: user.id,
            type: "subscription",
            description: "Subscription cancelled, downgraded to free",
            stripeTransactionId: subscription.id,
          });
        }
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;

        // Find user and refresh credits
        const userList = await db
          .select()
          .from(users);

        const user = userList.find(u => u.stripeCustomerId === customerId);

        if (user) {
          const newCredits = user.plan === "creator" ? 1000 : user.plan === "business" ? 5000 : 100;
          await db
            .update(users)
            .set({
              credits: newCredits,
              subscriptionStatus: "active",
            })
            .where(eq(users.id, user.id));
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook error:", error);
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    );
  }
}
