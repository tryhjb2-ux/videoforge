import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  projects,
  videoRenders,
  users,
  scenes,
  avatars,
  voices,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";

async function getUserFromRequest(request: NextRequest) {
  const userId = request.headers.get("x-user-id");
  if (!userId) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId));

  return user[0] || null;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    const proj = project[0];

    // Check if user has enough credits
    // Video rendering costs 50 credits
    if (user.credits < 50) {
      return NextResponse.json(
        { error: "Insufficient credits. Upgrade your plan." },
        { status: 402 }
      );
    }

    // Fetch project scenes
    const projectScenes = await db
      .select()
      .from(scenes)
      .where(eq(scenes.projectId, projectId));

    if (projectScenes.length === 0) {
      return NextResponse.json(
        { error: "No scenes in project" },
        { status: 400 }
      );
    }

    // Create video render entry
    const render = await db
      .insert(videoRenders)
      .values({
        projectId,
        status: "queued",
        creditsCost: 50,
        externalProvider: "heygen", // Default to HeyGen for demo
      })
      .returning();

    // Deduct credits from user
    await db
      .update(users)
      .set({
        credits: user.credits - 50,
        creditsUsed: user.creditsUsed + 50,
      })
      .where(eq(users.id, user.id));

    // In a real implementation, this would:
    // 1. Call HeyGen API, D-ID, or Synthesia to generate video
    // 2. Queue a background job with Bull/Agenda
    // 3. Return job ID for polling

    // For demo purposes, we'll simulate the API call
    // In production, integrate with:
    // - HeyGen API: https://docs.heygen.com/
    // - D-ID API: https://docs.d-id.com/
    // - Synthesia API: https://synthesia.readme.io/

    return NextResponse.json(
      {
        ...render[0],
        message: "Video render queued. Check back soon!",
      },
      { status: 202 }
    );
  } catch (error) {
    console.error("Render video error:", error);
    return NextResponse.json(
      { error: "Failed to queue video render" },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    // Get video renders for this project
    const renders = await db
      .select()
      .from(videoRenders)
      .where(eq(videoRenders.projectId, projectId));

    return NextResponse.json(renders);
  } catch (error) {
    console.error("Get renders error:", error);
    return NextResponse.json(
      { error: "Failed to fetch renders" },
      { status: 500 }
    );
  }
}
