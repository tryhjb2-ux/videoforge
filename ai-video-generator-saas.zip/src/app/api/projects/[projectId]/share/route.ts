import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { shareLinks, projects, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

async function getUserFromRequest(request: NextRequest) {
  const userId = request.headers.get("x-user-id");
  if (!userId) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId));

  return user[0] || null;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { allowDownload } = body;

    // Generate unique token
    const token = uuidv4();

    // Create share link
    const newLink = await db
      .insert(shareLinks)
      .values({
        projectId,
        token,
        allowDownload: allowDownload || false,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      })
      .returning();

    const shareUrl = `${process.env.NEXT_PUBLIC_APP_URL}/watch/${token}`;

    return NextResponse.json({
      ...newLink[0],
      shareUrl,
    });
  } catch (error) {
    console.error("Create share link error:", error);
    return NextResponse.json(
      { error: "Failed to create share link" },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    // Get share links for this project
    const links = await db
      .select()
      .from(shareLinks)
      .where(eq(shareLinks.projectId, projectId));

    return NextResponse.json(
      links.map((link) => ({
        ...link,
        shareUrl: `${process.env.NEXT_PUBLIC_APP_URL}/watch/${link.token}`,
      }))
    );
  } catch (error) {
    console.error("Get share links error:", error);
    return NextResponse.json(
      { error: "Failed to fetch share links" },
      { status: 500 }
    );
  }
}
