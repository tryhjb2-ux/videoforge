import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { scenes, projects, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

async function getUserFromRequest(request: NextRequest) {
  const userId = request.headers.get("x-user-id");
  if (!userId) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId));

  return user[0] || null;
}

const createSceneSchema = z.object({
  duration: z.number().positive(),
  text: z.string(),
  avatarId: z.string().optional(),
  voiceId: z.string().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    const projectScenes = await db
      .select()
      .from(scenes)
      .where(eq(scenes.projectId, projectId));

    return NextResponse.json(projectScenes);
  } catch (error) {
    console.error("Get scenes error:", error);
    return NextResponse.json(
      { error: "Failed to fetch scenes" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  try {
    const { projectId } = await params;
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify project ownership
    const project = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.userId, user.id)
        )
      );

    if (project.length === 0) {
      return NextResponse.json(
        { error: "Project not found" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { duration, text, avatarId, voiceId } = createSceneSchema.parse(body);

    // Get next order index
    const lastScene = await db
      .select()
      .from(scenes)
      .where(eq(scenes.projectId, projectId));

    const orderIndex = lastScene.length;

    const newScene = await db
      .insert(scenes)
      .values({
        projectId,
        orderIndex,
        duration: duration.toString(),
        text,
        avatarId,
        voiceId,
      })
      .returning();

    return NextResponse.json(newScene[0], { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Invalid input", details: error.flatten() },
        { status: 400 }
      );
    }
    console.error("Create scene error:", error);
    return NextResponse.json(
      { error: "Failed to create scene" },
      { status: 500 }
    );
  }
}
